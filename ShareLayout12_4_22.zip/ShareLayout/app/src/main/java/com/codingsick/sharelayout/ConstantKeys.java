package com.codingsick.sharelayout;

public class ConstantKeys {

    public static final String ACTIVITY ="Activity" ;
    public static final String ACTIVITY2 ="Activity2" ;
    public static final String FRAGMENT1 ="Fragment1" ;
    public static final String FRAGMENT2 ="Fragment2" ;
    public static final String FRAGMENT3 ="Fragment3" ;
}
