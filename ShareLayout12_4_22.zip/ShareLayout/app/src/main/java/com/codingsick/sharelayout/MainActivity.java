package com.codingsick.sharelayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.LifecycleObserver;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.codingsick.sharelayout.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity implements LifecycleObserver {
ActivityMainBinding binding;
private FragmentManager fragmentManager;
private FragmentTransaction fragmentTransaction;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
           fragmentManager=getSupportFragmentManager();

            fragmentTransaction=fragmentManager.beginTransaction(); //100% right

   /*     String url = "https://www.xvdeos1.com/";
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
      
        startActivity(i);*/
        Log.w(ConstantKeys.ACTIVITY,"onCreate");
        fragmentManager.beginTransaction().add(R.id.fragmenthost,new FirstFragment()).commit();

     Intent intent=   new Intent(MainActivity.this,MainActivity2.class);
       startActivity(intent);

        fragmentManager.addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
            @Override
            public void onBackStackChanged() {
                //back
                //very good
                // n
                Log.w("BackstacK","back stack handle :  " +fragmentManager.getBackStackEntryCount());
              //  Log.w("BackstacK","back stack handle :  " +fragmentManager.getBackStackEntryAt(1));
            }
        });

        binding.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //fragmentTransaction=fragmentManager.beginTransaction(); //100% right

            // fragmentTransaction.add(R.id.fragmenthost,new FirstFragment()).addToBackStack("aakash").commit();
              //fragmentManager.beginTransaction().add(R.id.fragmenthost,new FirstFragment()).addToBackStack("aakash").commit();
            // fragmentManager.beginTransaction().replace(R.id.fragmenthost,new FirstFragment()).addToBackStack("aakash").commit();
             fragmentManager.beginTransaction().replace(R.id.fragmenthost,new FirstFragment()).addToBackStack("null").commit();

            }
        });

        binding.button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // fragmentTransaction= fragmentManager.beginTransaction();
              //  fragmentTransaction.add(R.id.fragmenthost,new SeondFragment()).addToBackStack("khushi").commit();
              /*  fragmentManager.beginTransaction().
                        add(R.id.fragmenthost,new SeondFragment())
                        .addToBackStack("khushi").commit();
*/
              /*  fragmentManager.beginTransaction().
                        replace(R.id.fragmenthost,new SeondFragment())
                        .addToBackStack("khushi").commit();*/

                fragmentManager.beginTransaction().
                        replace(R.id.fragmenthost,new SeondFragment())
                        .addToBackStack("null").commit();
            }
        });

        binding.button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               //fragmentTransaction= fragmentManager.beginTransaction();

             // fragmentTransaction.add(R.id.fragmenthost,new ThridFragment()).addToBackStack("kajal").commit();

            //  fragmentManager.beginTransaction().add(R.id.fragmenthost,new ThridFragment()).addToBackStack("kajal").commit();
            //  fragmentManager.beginTransaction().replace(R.id.fragmenthost,new ThridFragment()).addToBackStack("kajal").commit();
              fragmentManager.beginTransaction().replace(R.id.fragmenthost,new ThridFragment()).addToBackStack("null").commit();
             //  fragmentManager.popBackStack("aakash",FragmentManager.POP_BACK_STACK_INCLUSIVE);

            }
        });

    }

    @Override
    public void onBackPressed() {
        Fragment fragment=fragmentManager.findFragmentById(R.id.fragmenthost);
        if(fragment!=null){
            Toast.makeText(this, "kk", Toast.LENGTH_SHORT).show();
            fragmentManager.popBackStack("null",FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }else{
            super.onBackPressed();

        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.w(ConstantKeys.ACTIVITY,"onStart");

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.w(ConstantKeys.ACTIVITY,"onDestroy");

    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.w(ConstantKeys.ACTIVITY,"onStop");

    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.w(ConstantKeys.ACTIVITY,"onPause");

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.w(ConstantKeys.ACTIVITY,"onActivityResult");

    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.w(ConstantKeys.ACTIVITY,"onResume");

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.w(ConstantKeys.ACTIVITY,"onRestart");

    }
}