package com.codingsick.sharelayout;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.text.Html;
import android.util.Log;

import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

public class ImageGetter implements Html.ImageGetter {
    //private AppTextView textView = null;
    Drawable drawable;
  static   Context context;
    public ImageGetter(Context mContext)
    {
        this.context=mContext;

    }

    public ImageGetter() {

    }



    @Override
    public Drawable getDrawable(String s) {
        //observer
        Picasso.get()
                .load(Uri.parse("https://d3bioexaf647f4.cloudfront.net/user_6081603a4fe69c275f3a22d1/packages/question/test-62e909894fda7b2e81067ce4-621d0c1d5eda2f2e923c573c/media/image1.png"))
                .into(new Target() {
                    @Override
                    public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                       // drawable=new BitmapDrawable(bitmap);
                        drawable=new BitmapDrawable(context.getResources(),bitmap);
                       // drawable=getDrawable(s);
                        drawable.setBounds(0,0,drawable.getIntrinsicWidth(),drawable.getIntrinsicHeight());
                       // bitmap.reconfigure(drawable.getIntrinsicWidth(),drawable.getIntrinsicHeight(),bitmap);
                    }

                    @Override
                    public void onBitmapFailed(Exception e, Drawable errorDrawable) {

                    }

                    @Override
                    public void onPrepareLoad(Drawable placeHolderDrawable) {

                    }
                });

        Log.d("data", "getDrawable: "+s);
        return drawable;
    }


}
