package com.codingsick.sharelayout;

public interface BitmapDrawablePlaceHolder {
}
