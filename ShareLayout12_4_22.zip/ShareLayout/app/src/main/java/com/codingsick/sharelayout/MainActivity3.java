package com.codingsick.sharelayout;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.text.Spannable;
import android.util.Log;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.io.IOException;
import java.net.URI;

public class MainActivity3 extends AppCompatActivity  {
    private static final String TAG ="data" ;
    private TextView mTextView, textView;
    Spannable html;
    WebView imageView;
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        new ImageGetter(this);

        mTextView=findViewById(R.id.txview);
        textView=findViewById(R.id.textView3);
       // imageView=findViewById(R.id.imageView);

        PicassoImageGetter imageGetter = new PicassoImageGetter(mTextView,this);

        //file:///android_asset/

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            html = (Spannable) Html.fromHtml(ConstentClass.data, Html.FROM_HTML_MODE_LEGACY,imageGetter, null);
        } else {
            html = (Spannable) Html.fromHtml(ConstentClass.data,imageGetter , null);
        }
        mTextView.setText(html);







      //  Glide.with(this).load(Uri.parse("https://d3bioexaf647f4.cloudfront.net/user_6081603a4fe69c275f3a22d1/packages/question/test-62e909894fda7b2e81067ce4-621d0c1d5eda2f2e923c573c/media/image1.png")).into(imageView);
        // mTextView.setText(Html.fromHtml(ConstentClass.data,Html.FROM_HTML_MODE_COMPACT));


        //---mTextView.setText(Html.fromHtml(ConstentClass.data,new ImageGetter(),null));


      //textView.setText(URI.create("https://d3bioexaf647f4.cloudfront.net/user_6081603a4fe69c275f3a22d1/packages/question/test-62e909894fda7b2e81067ce4-621d0c1d5eda2f2e923c573c/media/image1.png")+R.drawable.ic_launcher_background);

          //----   imageView.getSettings().setJavaScriptEnabled(true);

          //  imageView.loadUrl(String.valueOf(getAssets().open("mypage.html")));
           //imageView.loadUrl(String.valueOf("file:///android_asset/mypage.html"));



    }



}