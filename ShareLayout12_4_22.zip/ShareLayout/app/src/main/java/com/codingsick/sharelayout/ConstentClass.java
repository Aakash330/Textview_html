package com.codingsick.sharelayout;

public class ConstentClass {
    static String data="<h2><span style=\"font-family:Aachen BT;\">SECTION &ndash; I (</span><span style=\"font-family:Aachen BT;\">CHEMISTRY :</span><span style=\"font-family:Aachen BT;\"> </span><span style=\"height:35px\">Single Choice Questions)</span></h2><br />\r\n<span style=\"font-family:;\">This Section contains 20 questions. Each question has </span><span style=\"font-family:;font-weight: bold;\">FOUR</span><span style=\"font-family:;\"> choices (A</span><span style=\"font-family:;\">) ,</span><span style=\"font-family:;\"> (B), (C) and (D), out of which ONLY ONE is correct. (Marking </span><span style=\"font-family:;\">Scheme :</span><span style=\"font-family:;\"> + 4, </span><span style=\"font-family:;\">1) </span>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img src=\"https://d3bioexaf647f4.cloudfront.net/user_6081603a4fe69c275f3a22d1/packages/question/test-62e909894fda7b2e81067ce4-621d0c1d5eda2f2e923c573c/media/image1.png\" /><br />\r\n<span style=\"font-family:;\">can undergo which substitution </span><span style=\"font-family:;\">reaction :</span><span style=\"font-family:;\"> </span></p>";

}
